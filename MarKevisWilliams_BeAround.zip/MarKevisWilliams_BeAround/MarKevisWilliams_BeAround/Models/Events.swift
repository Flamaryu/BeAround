//
//  Events.swift
//  MarKevisWilliams_BeAround
//
//  Created by markevis williams on 4/13/22.
//

import Foundation
class Event{
    
}
